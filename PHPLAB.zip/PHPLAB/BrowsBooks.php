<!doctype html> 
<html>
	<head> 
		<title>My title</title>
		<meta name="description" content="FAQ- Particle Lovers" />
		<meta charset="utf-8"/>
		<link href="css/style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<header>
			<?php include("header.php"); ?>
		</header>
		<main>
			<div class="parent">
				<div class="searchbooks">
					<form action="BrowsBooks.php" method="POST">
						<p>
							Title
						</p>
						<input type="text" name="searchtitle">
						<p>
							Author
						</p>
						<input type="text" name="searchauthor" >
						<input type="submit" value="Search">
					</form>
				</div>
				<div class="reservebooks">
					<h3>Books</h3>
                    <hr> </hr>
                    <?php

                    $searchtitle = "";
                    $searchauthor = "";

                    if (isset($_POST) && !empty($_POST)) {
                    # Get data from form
                        $searchtitle = trim($_POST['searchtitle']);
                        $searchauthor = trim($_POST['searchauthor']);

                    
                    }

                    $searchtitle = addslashes($searchtitle);
                    $searchauthor = addslashes($searchauthor);

                    $searchauthor = htmlentities($searchauthor);
                    $searchauthor = htmlentities($searchauthor);

                    # Open the database
                    @ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

                    if ($db->connect_error) {
                        echo "could not connect: " . $db->connect_error;
                        printf("<br><a href=index.php>Return to home page </a>");
                        exit();
                    }

                    # Build the query. Users are allowed to search on title, author, or both

                    $query = " SELECT ISBN, title, author, onloan FROM Books";
                    if ($searchtitle && !$searchauthor) { // Title search only
                        $query = $query . " where title like '%" . $searchtitle . "%'";
                    }
                    if (!$searchtitle && $searchauthor) { // Author search only
                        $query = $query . " where author like '%" . $searchauthor . "%'";
                    }
                    if ($searchtitle && $searchauthor) { // Title and Author search
                        $query = $query . " where title like '%" . $searchtitle . "%' and author like '%" . $searchauthor . "%'"; // unfinished
                    }

                   
                    # Here's the query using bound result parameters
                        // echo "we are now using bound result parameters <br/>";
                        $stmt = $db->prepare($query);
                        $stmt->bind_result($ISBN, $title, $author, $onloan);
                        $stmt->execute();

                        echo '<table bgcolor="" cellpadding="6" width="100%">';
                        echo '<tr><b> <td>ISBN</td> <td>Title</td> <td>Author</td> <td>Reserved?</td> <td>Reserve</td> </b> </tr>';
                        while ($stmt->fetch()) {
                            if($onloan==0)
                                $onloan="NO";
                            else $onloan="YES";

                            echo "<tr>";
                            echo "<td> $ISBN </td><td> $title </td><td> $author </td><td> $onloan </td>";
                            echo '<td><a href="reserveBook.php?ISBN=' . urlencode($ISBN) . '"> <input type="button" value="Reserve"> </a></td>';
                            echo "</tr>";
                        }
                        echo "</table>";
                        ?>
					
				</div>
			</div>
		</main>
		<footer>
				<?php include("footer.php"); ?>
		</footer>
	</body>

</html>