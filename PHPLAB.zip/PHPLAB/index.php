<!doctype html> 
<html>
	<head> 
		<title>My title</title>
		<meta name="description" content="FAQ- Particle Lovers" />
		<meta charset="utf-8"/>
		<link href="css/style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<header>
			<?php include("header.php"); ?>
		</header>
		<main>
			<div class="bodytext">
				<h1>
					WELCOME!
				</h1>
				<p>
					Would you like to reserve some books? 
				</p>
			</div>
		</main>
		<footer>
				<?php include("footer.php"); ?>
		</footer>
	</body>

</html>