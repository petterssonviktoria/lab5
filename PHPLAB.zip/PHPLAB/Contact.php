<!doctype html> 
<html>
	<head> 
		<title>My title</title>
		<meta name="description" content="FAQ- Particle Lovers" />
		<meta charset="utf-8"/>
		<link href="css/style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<header>
		<?php include("header.php"); ?>
		</header>
		<main>
			<form class="contact">
				<?php
				   $Name = addslashes($Name); 
				   $Email = addslashes($Email);
				   $subject = addslashes($subject);

				   $Name = htmlentities($Name);
				   $Email = htmlentities($Emial);
				   $subject = htmlentities($subject);
				?>
				<p>
					Name
				</p>
				<input type="text" name="Name" placeholder="Eva Karlsson">
				<p>
					Email
				</p>
				<input type="text" name="Email" placeholder="evakarlsson@exampie.se">
				<p>
					Write some words
				</p>
				<textarea id="subject" name="subject" placeholder="Write something.." ></textarea>
				<input type="submit" value="Send">
			</form>
		
		</main>
		<footer>
				<?php include("footer.php"); ?>
		</footer>
	</body>

</html>