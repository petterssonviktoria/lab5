<!doctype html> 
<html>
	<head> 
		<title>My title</title>
		<meta name="description" content="FAQ- Particle Lovers" />
		<meta charset="utf-8"/>
		<link href="css/style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<header>
			<div class="headnav">
				<nav>
					<?php include 'config.php'; ?>
					<ul>
						<li>
							<a class="<?php echo ($current_page =='index.php'||$current_page=="") ? 'active' : NULL?>" 
               				 href="index.php">Home</a>
						</li>
						<li>
							<a class="<?php echo ($current_page =='Login.php'||$current_page=="") ? 'active' : NULL?>" 
               				 href="Login.php">Sign In</a>
						</li>
						<li>								
							
							<a class="<?php echo $current_page =='Aboutus.php' ? 'active' : NULL?>" 
               				 href="Aboutus.php">About us</a>
						</li>
						<li>
							<a class="<?php echo $current_page =='BrowsBooks.php' ? 'active' : NULL?>" 
           				     href="BrowsBooks.php">Browse Books</a>
							
						</li>
						<li>
							<a class="<?php echo $current_page =='Mybooks.php' ? 'active' : NULL?>" 
               				 href="Mybooks.php">My Books</a>
							
						</li>
						<li>
							<a class="<?php echo $current_page =='Gallery.php' ? 'active' : NULL?>" 
             			   href="Gallery.php">Gallery</a>
						</li>
						<li>
							<a class="<?php echo $current_page =='Contact.php' ? 'active' : NULL?>" 
             			   href="Contact.php">Contact</a>
						</li>
					</ul>
				</nav>
			</div>
			<div>
				<img src="foto/header.jpg">
			</div>
		</header>
	</body>

</html>	