<?php



@ $db = new mysqli('localhost', 'root', 'root', 'Book club'); 

if ($db->connect_error) {
    echo "could not connect: " . $db->connect_error;
    printf("<br><a href=index.php>Return to home page </a>");
    exit();
}


// var_dump($_POST);
if (isset($_POST['username'], $_POST['userpass'])) {
    #with statement under we're making it SQL Injection-proof
    $uname = mysqli_real_escape_string($db, $_POST['username']);
    
    
    $upass = sha1($_POST['userpass']);
    
    
    // echo "SELECT * FROM User WHERE username = '{$uname}' AND password = '{$upass}'";
    
    $query = ("SELECT * FROM User WHERE username = '{$uname}' "."AND password = '{$upass}'");
       
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    $stmt->store_result(); 
    
    $totalcount = $stmt->num_rows();
    
    
    
}
?>



<!doctype html> 
<html>
	<head> 
		<title>My title</title>
		<meta name="description" content="FAQ- Particle Lovers" />
		<meta http-equiv="Content-Type" content="text/html" charset="UTF-8" />
		<link href="css/style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<header>
			<?php include("header.php"); ?>
		</header>
		<main>
			<?php
        		if (isset($totalcount)) {
         			if ($totalcount == 0) {
              			echo '<h2>You got it wrong. Can\'t break in here!</h2>';
        			} else {
                		echo '<h2>Welcome! Correct password.</h2><p>Here is the link</p><a href="fileUpload.php"><input type="submit" value="Link"></a>';
                		
            		}
       			}
            $username = addslashes($username);
            $userpass = addslashes($userpass);

            $username = htmlentities($username);
            $userpass = htmlentities($userpass);
        	?>
       		<form method="POST" action="">
       			<p>Username</p>
            	<input type="text" name="username">
            	<p>Password</p>
           		<input type="password" name="userpass">
            	<input type="submit" value="Sign In">
        	</form>
		</main>
		<footer>
				<?php include("footer.php"); ?>
		</footer>
	</body>

</html>